Beacon native Go/Win32 LOCAL TEST BUILD v0.8.1.
Test on Windows 10/11. No Python or Go installation needed.
Compiled successfully but not yet launched on real Windows hardware.
This is the limited-feature preview, not the full Go/Fyne application.
