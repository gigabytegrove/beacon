#!/usr/bin/env bash
set -Eeuo pipefail
rm -f "$HOME/.local/bin/beacon-messenger" "$HOME/.local/share/applications/beacon-messenger.desktop" "$HOME/.local/share/icons/hicolor/64x64/apps/beacon-messenger.png"
echo 'Beacon executable and launcher removed. Your server address preference is preserved.'
