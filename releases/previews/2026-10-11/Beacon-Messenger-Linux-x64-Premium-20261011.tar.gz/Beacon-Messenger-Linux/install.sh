#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BIN="$HOME/.local/bin"
APP="$HOME/.local/share/applications"
ICON="$HOME/.local/share/icons/hicolor/64x64/apps"
mkdir -p "$BIN" "$APP" "$ICON"
install -m 0755 "$HERE/Beacon-Messenger-Linux-x64" "$BIN/beacon-messenger"
install -m 0644 "$HERE/beacon-icon.png" "$ICON/beacon-messenger.png"
cat > "$APP/beacon-messenger.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Beacon Messenger
Comment=Self-hosted instant messaging
Exec=$BIN/beacon-messenger
Icon=beacon-messenger
Terminal=false
Categories=Network;Chat;InstantMessaging;
StartupNotify=true
EOF
chmod 0644 "$APP/beacon-messenger.desktop"
echo "Beacon installed. Launch it from your application menu or: $BIN/beacon-messenger"
